%pyspark #5.1 统计每年的打卡次数
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import count, sum, to_date
sc = spark.sparkContext
hc = HiveContext(sc)

# 读取checkin数据
checkin = hc.table("checkin")
# 统计每年的打卡次数
checkin_year= checkin.withColumn("checkin_date", to_date("checkin_dates"))

# 统计每年的打卡次数
result = checkin_year.groupBy(year("checkin_date").alias("year")) .count() .orderBy("year")

# 显示结果
z.show(result)

%pyspark #5.2 统计24小时每小时打卡次数
from pyspark.sql.types import TimestampType
from pyspark.sql.functions import to_timestamp, hour
sc = spark.sparkContext
hc = HiveContext(sc)

checkin = hc.table("checkin")
time_format = "yyyy-MM-dd HH:mm:ss"
if checkin.schema['checkin_dates'].dataType != TimestampType():
   checkin_df = checkin.withColumn('checkin_dates', to_timestamp('checkin_dates', time_format))
checkin_hour = checkin_df.withColumn('hour', hour('checkin_dates'))
hourly_counts = checkin_hour.groupBy('hour').count()
hourly_counts_sorted = hourly_counts.orderBy('hour')
z.show(hourly_counts_sorted)

%pyspark #5.3 统计最喜欢的打卡城市
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import count, sum, col
sc = spark.sparkContext
hc = HiveContext(sc)

checkin = hc.table("checkin")
business = hc.table("business")

# 从 checkin_df 中计算每个 business_id 的 checkin 次数
business_checkin_counts = checkin.groupBy('business_id').agg(count('checkin_dates').alias('checkin_count'))

# 将 business_checkin_counts 与 business_df 通过 business_id 字段连接
business_checkin_ranks = business_checkin_counts.join(business, on='business_id', how='left')

# 按 city 分组并求和 checkin_count
city_checkin_ranks = business_checkin_ranks.groupBy('city').agg(sum('checkin_count').alias('total_checkin_count')).orderBy('total_checkin_count', ascending=False)

# 显示前 10 个结果
top10_city_checkin_ranks=city_checkin_ranks.limit(10)
z.show(top10_city_checkin_ranks)

%pyspark #5.4 全部商家的打卡排行榜
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import count, sum
checkin = hc.table("checkin")
business = hc.table("business")

# 从 checkin_df 中计算每个 business_id 的 checkin 次数
business_checkin_counts = checkin.groupBy('business_id').agg(count('checkin_dates').alias('checkin_count'))

# 将 business_checkin_counts 与 business_df 通过 business_id 字段连接
business_checkin_ranks = business_checkin_counts.join(business, on='business_id', how='left')

# 按 name 分组并求和 checkin_count
business_checkin_ranks = business_checkin_ranks.groupBy('name').agg(sum('checkin_count').alias('checkin_count'))

# 按 checkin_count 降序排序
business_checkin_ranks_sorted = business_checkin_ranks.orderBy('checkin_count', ascending=False)

# 创建一个新的 DataFrame,只包含前 10 行
top_10_businesses = business_checkin_ranks_sorted.limit(10)

# 显示新 DataFrame 的内容
z.show(top_10_businesses)
