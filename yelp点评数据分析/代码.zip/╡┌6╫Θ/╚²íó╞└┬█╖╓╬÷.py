%pyspark#3.1 统计每年的评论数
from pyspark.sql import HiveContext
from pyspark.sql.functions import split, explode, col, year, count, sum, col, desc, rank
review = hc.table("review")
hc = HiveContext(sc)
result = review.groupBy(year("rev_date").alias("year")).count().orderBy(desc("year"))
z.show(result)

%pyspark#3.2 统计有用（useful）、有趣（funny）及酷（cool）的评论及数量
from pyspark.sql import HiveContext
from pyspark.sql.functions import split, explode, col, year, count, sum, col, desc, rank
review = hc.table("review")
hc = HiveContext(sc)
# 有用的评论及数量
result_useful = review.filter(col('rev_useful') > 0).select('rev_text', 'rev_useful').limit(100)
total_useful = review.filter(col('rev_useful') > 0).count()

z.show(result_useful)
z.show(hc.createDataFrame([(total_useful,)], ["total_useful_review"]))

# 有趣的评论及数量
result_funny = review.filter(col('rev_funny') > 0).select('rev_text', 'rev_funny').limit(100)
total_funny = review.filter(col('rev_funny') > 0).count()

z.show(result_funny)
z.show(hc.createDataFrame([(total_funny,)], ["total_funny_review"]))

# 酷的评论及数量
result_cool = review.filter(col('rev_cool') > 0).select('rev_text', 'rev_cool').limit(100)
total_cool = review.filter(col('rev_cool') > 0).count()

z.show(result_cool)
z.show(hc.createDataFrame([(total_cool,)], ["total_cool_review"]))

%pyspark#3.3 统计每年全部评论用户排行榜
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.window import Window
from pyspark.sql.functions import split, explode, col, year, count, sum, desc, rank

sc = spark.sparkContext
hc = HiveContext(sc)

# 读取HIVE数据
review = hc.table("review")
users = hc.table("users")

# 加载用户名字，并将'user_name'列重命名为'name'
user_names = users.select("user_id", col("user_name").alias("name"))

# 定义窗口函数，按年份分组，评论数降序排序
window = Window.partitionBy('year').orderBy(col('cnt').desc())

# 计算每年每个用户的评论数，然后使用窗口函数找出每年评论最多的用户
result = review.groupBy(year('rev_date').alias('year'), 'rev_user_id') .agg(count('review_id').alias('cnt')) .withColumn('rank', rank().over(window))

# 添加用户名字
result_with_names = result.join(user_names, result.rev_user_id == user_names.user_id, 'left') .select('year', 'name', 'cnt', 'rank')

# 最后，对这些用户的评论数进行比较，输出排行榜
final_result = result_with_names.filter(col('rank') <= 10) .orderBy('year', 'rank')

# 修改结果展示方式
z.show(final_result)

%pyspark#3.4 从评论中提取最常见的Top20词语
from pyspark.sql import HiveContext
from pyspark.sql.functions import split, explode, col, year, count, sum, col, desc, rank

sc = spark.sparkContext
hc = HiveContext(sc)
review = hc.table("review")

words = review.select(explode(split(col("rev_text"), " ")).alias("word"))
word_counts = words.groupBy("word").count().orderBy(col("count").desc())
z.show(word_counts)

%pyspark#3.5从评论中提取负面评论（评分>3）的Top10词语
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.window import Window
from pyspark.sql.functions import split, explode, col, year, count, desc

sc = spark.sparkContext
hc = HiveContext(sc)

# 连接HIVE，读取HIVE数据
review = hc.table("review")

# 过滤出正面评论（评分 > 3）
positive_reviews = review.filter(col("rev_stars") > 3)

# 将评论文本拆分为单词
words = positive_reviews.select(explode(split(col("rev_text"), " ")).alias("word"))

# 统计每个词语的出现次数
word_counts = words.groupBy("word").agg(count("word").alias("count")).orderBy(desc("count"))

# 显示前10个常见词语
z.show(word_counts.limit(10))

%pyspark#3.6 从评论中提取负面评论（评分<=3）的Top10词语
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import split, explode, col, desc

sc = spark.sparkContext
hc = HiveContext(sc)

# 连接HIVE，读取HIVE数据
review = hc.table("review")

# 过滤出负面评论（评分 <= 3）
negative_reviews = review.filter(col("rev_stars") <= 3)

# 将评论文本拆分为单词
words = negative_reviews.select(explode(split(col("rev_text"), " ")).alias("word"))

# 统计每个词语的出现次数，并按次数降序排序
word_counts = words.groupBy("word").agg(count("word").alias("count")).orderBy(desc("count"))

# 显示前10个常见词语
z.show(word_counts.limit(10))

%pyspark #3.7 提取全部评论、通过词性过滤，并完成词云分析（Word Cloud）此代码需要再python上运行
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, split, lower
from pyspark.ml.feature import StopWordsRemover
from wordcloud import WordCloud
import matplotlib.pyplot as plt
spark = SparkSession.builder \
    .appName("Yelp Review WordCloud") \
    .getOrCreate()
df = spark.read.json("D:/项目文件/yelp_academic_dataset_review.json")
text_df = df.select("text")
print(text_df)
words_df = text_df.select(split(lower(col("text")), r'\W+').alias("words"))
remover = StopWordsRemover(inputCol="words", outputCol="filtered_words")
filtered_words_df = remover.transform(words_df)
word_freq = filtered_words_df.selectExpr("explode(filtered_words) as word") \
    .where(col("word") != "") \
    .groupBy("word") \
    .count()
# 收集词频数据到Python列表
word_freq_list = word_freq.rdd.map(lambda row: (row[0], row[1])).collect()

# 关闭SparkSession
spark.stop()

# 生成词云
wordcloud = WordCloud(width=800, height=400, background_color="white").generate_from_frequencies(dict(word_freq_list))

# 显示词云
plt.figure(figsize=(10, 5))
plt.imshow(wordcloud, interpolation='bilinear')
plt.axis("off")
plt.show()

%pyspark #3.8  计算单词的关系图（譬如cheese关系图、steak等单词）
import json
import networkx as nx
import matplotlib.pyplot as plt
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
from collections import Counter

# # 设置停用词和标点符号
stop_words = set(stopwords.words('english'))
punctuation = set(['.', ',', '!', '?', ';', ':', '"', "'", '(', ')', '[', ']', '{', '}'])
#
# # 读取json文件
with open('D:/项目文件/yelp_academic_dataset_review.json', 'r') as f:
    reviews = []
    for i, line in enumerate(f):
        if i == 100:  # 只处理前100行数据
            break
        reviews.append(json.loads(line))

# # 对每个评论的'text'字段进行处理
word_graph = nx.Graph()
for review in reviews:
    text = review['text']
    words = word_tokenize(text)
    words = [word.lower() for word in words if word.isalpha()]
    words = [word for word in words if word not in stop_words and word not in punctuation]
    word_counts = Counter(words)

#     # 添加节点到图中
    for word, count in word_counts.items():
        if word not in word_graph:
            word_graph.add_node(word, count=count)
        else:
            word_graph.nodes[word]['count'] += count

    # 只添加与'cheese'相关的边
    if 'cheese' in word_counts:
        for word in word_counts:
            if word == 'cheese':
                continue
            if word_graph.has_edge('cheese', word):
                word_graph.edges['cheese', word]['weight'] += 1
            else:
                word_graph.add_edge('cheese', word, weight=1)

    # 只添加与'steak'相关的边
    if 'steak' in word_counts:
        for word in word_counts:
            if word == 'steak':
                continue
            if word_graph.has_edge('steak', word):
                word_graph.edges['steak', word]['weight'] += 1
            else:
                word_graph.add_edge('steak', word, weight=1)

# # 绘制图形
plt.figure(figsize=(20, 20))  # 增大图形的大小
pos = nx.spring_layout(word_graph, k=0.15)
nx.draw_networkx_nodes(word_graph, pos, node_size=[v * 10 for v in dict(word_graph.nodes.data('count')).values()])
nx.draw_networkx_edges(word_graph, pos, alpha=0.5)
nx.draw_networkx_labels(word_graph, pos, font_size=8)  # 减小标签的字体大小
plt.show()
