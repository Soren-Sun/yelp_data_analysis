%pyspark  # 1.1 找出美国最常见商户（前20）
from pyspark.sql import HiveContext

hc = HiveContext(sc)
result = hc.sql("SELECT name, COUNT(name) as name_count FROM business GROUP BY name ORDER BY name_count DESC LIMIT 20")

z.show(result)

%pyspark#1.2 找出美国商户最多的前10个城市
from pyspark.sql import functions as F
from pyspark.sql import HiveContext

sc = spark.sparkContext

hc = HiveContext(sc)
business = hc.table("business")

result = business.groupBy("city").agg(F.count("city").alias("city_count")).orderBy(F.desc("city_count")).limit(10)
z.show(result)

%pyspark#1.3 找出美国商户最多的前5个州
from pyspark.sql import HiveContext
hc = HiveContext(sc)
business = hc.table("business")
result = business.groupBy("state").agg(F.count("state").alias("state_count")).orderBy(F.desc("state_count")).limit(5)
z.show(result)

%pyspark#1.4 找出美国最常见商户，并显示平均评分（前20）
from pyspark.sql import HiveContext
hc = HiveContext(sc)
business = hc.table("business")
result = business.groupBy("name").agg(F.count("name").alias("name_count"), F.avg("stars").alias("avg_stars")).orderBy(F.desc("name_count")).limit(20)
z.show(result)

%pyspark#1.5 找出美国商户最多的前10个城市
from pyspark.sql import HiveContext
hc = HiveContext(sc)
business = hc.table("business")
result = business.groupBy("city").agg(F.avg("stars").alias("avg_stars")).orderBy(F.desc("avg_stars")).limit(10)
z.show(result)

%pyspark#1.6 统计category的数量
from pyspark.sql import HiveContext
hc = HiveContext(sc)
business = hc.table("business")
result = business.agg(F.countDistinct("categories").alias("category_count"))
z.show(result)

%pyspark#1.7 统计最多的category及数量
from pyspark.sql import HiveContext
hc = HiveContext(sc)
business = hc.table("business")
result = business.groupBy("categories").agg(F.count("categories").alias("category_count")).orderBy(F.desc("category_count")).limit(10)
z.show(result)

%pyspark#1.8 收获五星评论最多的商户（前20）
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, count
from pyspark.sql.window import Window
sc = spark.sparkContext
hc = HiveContext(sc)
# 读取business和review数据
business_df = hc.table("business")
review_df = hc.table("review")
# 过滤出五星评论
five_star_reviews = review_df.filter(review_df.rev_stars == 5)
# 计算每个商户的五星评论数量
business_review_counts = five_star_reviews.groupBy('rev_business_id').agg(count('rev_business_id').alias('count'))
# 将商户信息与评论数量合并
result_df = business_df.join(business_review_counts, business_df.business_id == business_review_counts.rev_business_id)
# 按评论数量降序排序并取前20
top_20_businesses = result_df.orderBy(col('count').desc()).limit(20)
# 只保留商户的名字和统计的五星评论的数量
top_20_businesses = top_20_businesses.select('name', 'count')
# 显示结果
z.show(top_20_businesses)

%pyspark#1.9 统计不同类型（中国菜、美式、墨西哥）的餐厅类型及数量
from pyspark.sql import HiveContext
sc = spark.sparkContext

hc = HiveContext(sc)
business = hc.table("business")

# 统计中国菜餐厅的数量
result_chinese = business.filter(business.categories.like("%Chinese%")).filter(business.categories.like("%Restaurants%")).select("categories").limit(100)
z.show(result_chinese)
count_chinese = business.filter(business.categories.like("%Chinese%")).filter(business.categories.like("%Restaurants%")).count()
z.show(hc.createDataFrame([(count_chinese,)], ["Chinese_Restaurants_Count"]))

# 统计美式餐厅的数量
result_american = business.filter(business.categories.like("%American%")).filter(business.categories.like("%Restaurants%")).select("categories").limit(100)
z.show(result_american)
count_american = business.filter(business.categories.like("%American%")).filter(business.categories.like("%Restaurants%")).count()
z.show(hc.createDataFrame([(count_american,)], ["American_Restaurants_Count"]))

# 统计墨西哥餐厅的数量
result_mexican = business.filter(business.categories.like("%Mexican%")).filter(business.categories.like("%Restaurants%")).select("categories").limit(100)
z.show(result_mexican)
count_mexican = business.filter(business.categories.like("%Mexican%")).filter(business.categories.like("%Restaurants%")).count()
z.show(hc.createDataFrame([(count_mexican,)], ["Mexican_Restaurants_Count"]))

%pyspark#1.10 统计不同类型（中国菜、美式、墨西哥）的餐厅的评论数量
from pyspark.sql import HiveContext
sc = spark.sparkContext
hc = HiveContext(sc)
business = hc.table("business")

restaurant_types = ['Chinese', 'American', 'Mexican']
total_reviews = [business.filter((business.categories.contains("Restaurants")) & (business.categories.contains(rest_type))).agg(F.sum("review_count")).first()[0] for rest_type in restaurant_types]
result = dict(zip(restaurant_types, total_reviews))
df = sc.parallelize([Row(**result)]).toDF()
z.show(df)

%pyspark#1.11 统计不同类型（中国菜、美式、墨西哥）的餐厅的评分分布
from pyspark.sql import HiveContext
sc = spark.sparkContext
hc = HiveContext(sc)
business = hc.table("business")

avg_stars = [business.filter(business.categories.contains("Restaurants") & business.categories.contains(rest_type)).agg(F.avg("stars").alias("avg_stars")).first()[0] for rest_type in restaurant_types]
result = dict(zip(restaurant_types, avg_stars))
df = sc.parallelize([Row(**result)]).toDF()
z.show(df)


