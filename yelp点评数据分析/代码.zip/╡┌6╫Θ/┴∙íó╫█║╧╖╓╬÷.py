%pyspark #6.1 每个城市最好（评分次数、评分、打卡数）的五家商家
from pyspark.sql.functions import explode, col
from pyspark.sql.window import Window
from pyspark.sql.functions import rank
from pyspark.sql.functions import coalesce, lit
#  使用 groupBy 和 count 聚合函数来计算每个 business_id 的出现次数
checkin_df = hc.table("checkin")
business_df=hc.table("business")
checkin_counts = checkin_df.groupBy(col("business_id")).count()

# 重命名列名，使其更清晰
checkin_counts = checkin_counts .withColumnRenamed("count", "checkin_count")

# 显示结果

# 使用 left outer join 来连接两个表，基于 'business_id' 列
business_summary = business_df.join(checkin_counts, on='business_id', how='left_outer')

# 对于在 checkin_counts 表中没有出现的 business_id，其 checkin_count 应该是 0
# 使用 coalesce 函数，如果 checkin_count 是 null，那么返回 0，否则返回 checkin_count 的值
from pyspark.sql.functions import coalesce, lit

business_summary = business_summary.withColumn('checkin_count', coalesce(business_summary.checkin_count, lit(0)))

# 显示结果
# business_summary.show()
# 加载business_summary表


# 已知评论数量的最大和最小值
max_review_count = 8000
min_review_count = 0

# 正规化评论数量
business_summary = business_summary.withColumn("review_count_normalized",
                                               (col("review_count") - min_review_count) / (max_review_count - min_review_count))

# # 计算加权评分
business_summary = business_summary.withColumn("weighted_rating",
                                              (col("stars") * 0.6) + 
                                              (col("review_count_normalized") * 0.3) + 
                                              (col("checkin_count") * 0.1))
windowSpec = Window.partitionBy("city").orderBy(col("weighted_rating").desc())

# 使用rank()函数来计算排名
df_with_rank = business_summary.withColumn("rank", rank().over(windowSpec))

# 现在筛选出排名前五的数据
top_five_per_city = df_with_rank.filter(col("rank") <= 5)

# 最后，我们可以选择我们感兴趣的列并显示结果
# result = top_five_per_city.select("name", "weighted_rating", "city", "rank")
result = top_five_per_city.select("city","name", "rank")
z.show(result)
