%pyspark #4.1 统计评分的分布情况（1-5分）
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import col
review = hc.table("review")

rating_distribution = review.groupBy(col("rev_stars")).agg(F.count("*").alias("count"))
z.show(rating_distribution)

%pyspark#4.2 统计评分周（周一~周天）次数统计
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import col, to_date, dayofweek
sc = spark.sparkContext
hc = HiveContext(sc)
review = hc.table("review")
df = review.withColumn("rev_date_date", to_date("rev_date"))
result = df.groupBy(dayofweek("rev_date_date").alias("day_of_week")) .count() .orderBy("day_of_week")
z.show(result)

%pyspark #4.3 统计拥有次数最多的5分评价的商家
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import  col, count, desc

sc = spark.sparkContext
hc = HiveContext(sc)

# 读取business和review数据
business = hc.table("business")
review = hc.table("review")

# 过滤出五星评论
five_star_reviews = review.filter(review.rev_stars == 5)

# 计算每个商户的五星评论数量
business_review_counts = five_star_reviews.groupBy('rev_business_id').agg(F.count('rev_business_id').alias('count'))

# 将商户信息与评论数量合并
result = business.join(business_review_counts, business.business_id == business_review_counts.rev_business_id)

# 按评论数量降序排序并取前20
top_20_businesses = result.orderBy(F.desc('count')).limit(20)

# 只保留商户的名字和统计的五星评论的数量
top_20_businesses = top_20_businesses.select('name', 'count')

# 显示结果
z.show(top_20_businesses)
