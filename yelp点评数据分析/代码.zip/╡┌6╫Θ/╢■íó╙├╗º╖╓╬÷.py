%pyspark#2.1统计每年加入的用户数量
from pyspark.sql import HiveContext
sc = spark.sparkContext
hc = HiveContext(sc)
result = hc.sql("SELECT year(to_date(user_yelping_since)) as year, COUNT(*) FROM users GROUP BY year(to_date(user_yelping_since))")
z.show(result)

%pyspark#2.2统计评论达人（review_count）
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.window import Window
from pyspark.sql.functions import split, explode, col, year, count, sum, col, desc, rank

sc = spark.sparkContext
hc = HiveContext(sc)
review = hc.table("review")

# 每年全部评论用户排行榜
# 定义窗口函数，按年份分组，评论数降序排序
window = Window.partitionBy('year').orderBy(col('cnt').desc())
# 计算每年每个用户的评论数，然后使用窗口函数找出每年评论最多的用户
result = review.groupBy(year('rev_date').alias('year'), 'rev_user_id').agg(count('review_id').alias('cnt')).withColumn('rank', rank().over(window))

# 最后，对这些用户的评论数进行比较，输出排行榜
final_result = result.filter(col('rank') <= 10).orderBy('year', 'rank').select('year', 'rev_user_id', 'cnt', 'rank')
z.show(final_result)

%pyspark#2.3 统计人气最高的用户
from pyspark.sql import HiveContext
sc = spark.sparkContext
hc = HiveContext(sc)
users = hc.table("users")

result = (users.select('user_id', 'user_fans').orderBy(col('user_fans').desc()).limit(20))

z.show(result)

%pyspark#2.4统计每年优质用户和普通用户的比例
from pyspark.sql import HiveContext
from pyspark.sql.functions import split, explode, col, year, count, date_format, when, sum, desc
from pyspark.sql import functions as F
from pyspark.sql import Window

sc = spark.sparkContext
hc = HiveContext(sc)
users = hc.table("users")

users = users.filter("user_elite IS NOT NULL")
df_elite = users .select('user_elite','user_id') .withColumn('year',explode(split(col('user_elite'), ',')))
df_elite = df_elite .withColumn('year', F.when(F.col('year') == '20', '2020') .otherwise(F.col('year'))) .distinct()
df_elite = df_elite .select('year') .groupBy('year') .agg(count('year').alias('elite_count')) .orderBy(desc('year'))
row_count = df_elite.count()
df_elite = df_elite.limit(row_count - 1)

df_registered = users.withColumn("registration_year", date_format(col("user_yelping_since"), "YYYY"))
# 将 df_elite 和 df_registered 连接
df_registered = df_registered .select('user_id','registration_year') .groupBy('registration_year') .agg(count('registration_year').alias('zhuce_count'))
df_registered = df_registered .orderBy(desc('registration_year'))

# 定义一个窗口，包括当前行和所有之前的行
window_spec = Window.partitionBy().orderBy('registration_year').rowsBetween(Window.unboundedPreceding, 0)

# 使用窗口函数累积求和
df_registered = df_registered .withColumn('cumulative_user_count', sum('zhuce_count').over(window_spec)) .orderBy(desc('registration_year'))

# 重命名 df_elite 的 'year' 列为 'registration_year' 以匹配 df_registered 的列名
df_elite_renamed = df_elite.withColumnRenamed('year', 'registration_year')

# 执行 join 操作
df_joined = df_registered.join(df_elite_renamed, on='registration_year', how='left')
df_result = df_joined.withColumn("common_count", df_joined["cumulative_user_count"] - df_joined["elite_count"])
df_result = df_result .withColumn("radio", df_result["elite_count"] / df_result["common_count"])
df_result = df_result .select('registration_year','cumulative_user_count','elite_count','common_count','radio')
 # 显示结果
z.show(df_result)

%pyspark#2.5 统计每年总用户数和沉默用户数的比例
from pyspark.sql import HiveContext
from pyspark.sql.functions import split, explode, col, year, count, date_format, when, sum, desc
from pyspark.sql import functions as F
from pyspark.sql import Window
from pyspark.sql.types import IntegerType

sc = spark.sparkContext
hc = HiveContext(sc)
users = hc.table("users")
review = hc.table("review")

df_registered = users.withColumn("registration_year", date_format(col("user_yelping_since"), "YYYY"))
#1.计算每年的总用户数 = 上一年的总用户数 + 每年新注册的用户数
# 将 df_elite 和 df_registered 连接
df_registered = df_registered .select('user_id','registration_year') .groupBy('registration_year') .agg(count('registration_year').alias('registration_count'))
df_registered = df_registered .orderBy(desc('registration_year'))

# 定义一个窗口，包括当前行和所有之前的行
window_spec = Window.partitionBy().orderBy('registration_year').rowsBetween(Window.unboundedPreceding, 0)

# 使用窗口函数累积求和
df_registered = df_registered .withColumn('cumulative_user_count', sum('registration_count').over(window_spec)).orderBy(desc('registration_year'))

# 从rev_date列中提取年份，并将其作为新列year_added添加到DataFrame中
review = review.withColumn("year_added", F.year(review.rev_date).cast("integer"))

# 按照年份筛选每年参与评论的用户ID数
result = review.groupBy("year_added").agg(F.countDistinct(review.rev_user_id).alias("unique_user_count"))

# 将 df_registered 和 result 连接
joined_df = df_registered.join(result, df_registered.registration_year == result.year_added, "inner")

# 22.计算 silent_count 和 radio，每年的沉默用户数 = 每年的总用户数 - 参与评论的用户数
df_result = joined_df.select('registration_year', 'cumulative_user_count', 'unique_user_count')
df_result = df_result.withColumn("silent_count", df_result["cumulative_user_count"] - df_result["unique_user_count"])
df_result = df_result.withColumn("radio", df_result["silent_count"] / df_result["cumulative_user_count"]).orderBy(desc('registration_year'))

# 显示结果
z.show(df_result)

%pyspark# 2.6 统计出每年的新用户数、评论数、精英用户、tip数、打卡数
from pyspark.sql import HiveContext
from pyspark.sql.functions import split, explode, col, year, count, sum, col, desc, rank,trim,to_timestamp

sc = spark.sparkContext
hc = HiveContext(sc)
review = hc.table("review")
checkin = hc.table("checkin")
users = hc.table("users")
tip = hc.table("tip")

#统计出每年的新用户数
new_count = hc.sql("SELECT year(to_date(user_yelping_since)) as year, COUNT(*) FROM users GROUP BY year(to_date(user_yelping_since))")
z.show(new_count)

#统计出每年的评论数
total_count = review.groupBy(year("rev_date").alias("year")).count().orderBy(desc("year"))
z.show(total_count)

#统计出每年的精英用户数
df_elite = users .select('user_elite','user_id') .withColumn('year',explode(split(col('user_elite'),',')) .alias('year'))                 
df_elite = df_elite .withColumn('year', F.when(F.col('year') == '20', '2020') .otherwise(F.col('year'))) .distinct() 
df_elite = df_elite .select('year') .groupBy('year') .agg(count('year').alias('elite_count')) .orderBy(desc('year')) 
# 删除最后一行数据
row_count = df_elite.count()
df_elite = df_elite.limit(row_count - 1)
z.show(df_elite)

#统计出每年的tip数
b_df = b_df.withColumn('year', F.year('date'))
tips_per_year = b_df.groupBy('year').count().orderBy(desc('year'))
tips_per_year =tips_per_year.na.drop(how='any', subset=['year'])
z.show(tips_per_year)

#统计出每年的打卡数
checkin_count =checkin .select(col('business_id'), explode(split(col('checkin_dates'), ',')).alias('datetime')).select('business_id', year(to_timestamp(trim(col('datetime')))).alias('year')) .groupBy('year') .count() .orderBy(col("year").desc())
z.show(checkin_count)

